// {
//     "aboutUs": {
//         "title": "À propos de nous",
//         "cards": [
//             {
//                 "title": "Landa Holding",
//                 "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, diam eu tincidunt feugiat, velit elit bibendum sapien, vel bibendum sapien elit euismod diam.",
//                 "link": "/StartupsForm"
//             },
//             {
//                 "title": "Centre d'accélération",
//                 "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, diam eu tincidunt feugiat, velit elit bibendum sapien, vel bibendum sapien elit euismod diam.",
//                 "link": "/StartupsForm"
//             },
//             {
//                 "title": "Académie",
//                 "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, diam eu tincidunt feugiat, velit elit bibendum sapien, vel bibendum sapien elit euismod diam.",
//                 "link": "/academy"
//             }
//         ]
//     }
// }

export default {
    'hello': 'سلام',
    'hello.world': 'سلام جهان!',
    'welcome': 'سلام {name}!'
  } as const