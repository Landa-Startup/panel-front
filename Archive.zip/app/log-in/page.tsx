import React from 'react'
import LoginForm from '@/components/auth/login/LoginForm'
export default function page() {
  return (
    <div><LoginForm/></div>
  )
}
