import React from 'react'
import RegisterForm from '@/components/register/RegisterForm'
export default function page() {
  return (
    <RegisterForm/>
  )
}
