import React from 'react'

export default function LandaMagazinePost() {
  return (
    <div>LandaMagazinePost</div>
  )
}
