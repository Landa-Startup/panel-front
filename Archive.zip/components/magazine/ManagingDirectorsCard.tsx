import React from 'react'

export default function ManagingDirectorsCard() {
  return (
    <div>ManagingDirectorsCard</div>
  )
}
