import React from 'react';

export default function RightSection() {
  return <div className="w-3/12 bg-[#fff]">RightSection</div>;
}
